for n in {0..3}
do
	#python graficarn.py $n E2n-$n
	python graficars.py $n E2s-$n
done
#rm Tiempo*
